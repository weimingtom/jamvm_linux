/*
 * Copyright (C) 2003, 2004, 2005, 2006, 2007, 2008, 2009
 * Robert Lougher <rob@jamvm.org.uk>.
 *
 * This file is part of JamVM.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#include "jam.h"
#include "sig.h"
#include "frame.h"
#include "lock.h"
#include "symbol.h"
#include "excep.h"
#include "properties.h"
#include "jni-internal.h"
/*C 库宏 type va_arg(va_list ap, type) 检索函数参数列表中类型为 type 的下一个参数。它无法判断检索到的参数是否是传给函数的最后一个参数。*/
#define VA_DOUBLE(args, sp)                                 \
    if(*sig == 'D')                                         \
        *(double*)sp = va_arg(args, double);                \
    else                                                    \
        *(u8*)sp = va_arg(args, u8);                        \
    sp+=2
         
#define VA_SINGLE(args, sp)                                 \
    if(*sig == 'L' || *sig == '[')                          \
        *sp = va_arg(args, uintptr_t) & ~REF_MASK;          \
    else                                                    \
        if(*sig == 'F')                                     \
            *((float*)sp + IS_BE64) = va_arg(args, double); \
        else                                                \
            *sp = va_arg(args, u4);                         \
    sp++

#define JA_DOUBLE(args, sp)  *(u8*)sp = *args++; sp+=2
#define JA_SINGLE(args, sp)                                 \
    switch(*sig) {                                          \
        case 'L': case '[':                                 \
            *sp = *(uintptr_t*)args & ~REF_MASK;            \
            break;                                          \
        case 'F':                                           \
            *((float*)sp + IS_BE64) = *(float*)args;        \
            break;                                          \
        case 'B': case 'Z':                                 \
            *sp = *(signed char*)args;                      \
            break;                                          \
        case 'C':                                           \
            *sp = *(unsigned short*)args;                   \
            break;                                          \
        case 'S':                                           \
            *sp = *(signed short*)args;                     \
            break;                                          \
        case 'I':                                           \
            *sp = *(signed int*)args;                       \
            break;                                          \
    }                                                       \
    sp++; args++

#define ADJUST_RET_ADDR(ret_addr, ret_type) ({              \
    char *adjusted = ret_addr;                              \
    if(IS_BIG_ENDIAN) {                                     \
        int size;                                           \
        switch(ret_type) {                                  \
            case 'B': case 'Z':                             \
                size = sizeof(uintptr_t) - 1;               \
                break;                                      \
            case 'C': case 'S':                             \
                size = sizeof(uintptr_t) - 2;               \
                break;                                      \
            case 'I': case 'F':                             \
                size = sizeof(uintptr_t) - 4;               \
                break;                                      \
            default:                                        \
                size = 0;                                   \
                break;                                      \
        }                                                   \
        adjusted += size;                                   \
    }                                                       \
    adjusted;                                               \
})

/*
    看名字 执行方法
*/
void *executeMethodArgs(Object *ob, Class *class, MethodBlock *mb, ...) {
    va_list jargs; // TODO 这个是个啥？
    void *ret;
    // C 库宏 void va_start(va_list ap, last_arg) 初始化 ap 变量，它与 va_arg 和 va_end 宏是一起使用的。last_arg 是最后一个传递给函数的已知的固定参数，即省略号之前的参数。这个宏必须在使用 va_arg 和 va_end 之前被调用。
    va_start(jargs, mb);
    // TODO 这个二代吗调试一下
    ret = executeMethodVaList(ob, class, mb, jargs);
    va_end(jargs);

    return ret;
}

void *executeMethodVaList(Object *ob, Class *class, MethodBlock *mb,
                          va_list jargs) {
    
    // TODO 下次调试的时候，可以写一个简单的方法，看看这些参数到底含义是啥 ee里面的参数 Frame里面的数据 last_pc里面的数据
    ExecEnv *ee = getExecEnv();
    char *sig = mb->type; // 这个是啥？
    uintptr_t *sp; // 这个是啥?
    void *ret; // 这个是啥？
    // TODO 看名字就知道 创建顶帧
    CREATE_TOP_FRAME(ee, class, mb, sp, ret); // TODO 这个里面的处理我不是很懂 看结果，其实是在当前frame上又创建了两个（一个dummy，一个new_frame）意义何在？

    /* copy args onto stack 将args复制到堆栈上 */

    if(ob)
        *sp++ = (uintptr_t) ob; /* push receiver first */

    SCAN_SIG(sig, VA_DOUBLE(jargs, sp), VA_SINGLE(jargs, sp)) // TODO 扫描方法签名 这一步达成了什么效果？jargs是干嘛用的？

    if(mb->access_flags & ACC_SYNCHRONIZED) // 判断是否是一个加了synchronize关键字的方法
        objectLock(ob ? ob : mb->class); // 是的话 需要加锁

    if(mb->access_flags & ACC_NATIVE)  // 是否是一个native方法
        (*mb->native_invoker)(class, mb, ret); // TODO 这是啥语法 噢噢我知道了 native_invoker是一个方法
    else
        executeJava(); // TODO 很明显了 执行java 这个方法是真的长...

    if(mb->access_flags & ACC_SYNCHRONIZED) // 解锁
        objectUnlock(ob ? ob : mb->class);

    POP_TOP_FRAME(ee); // 出栈

    return ADJUST_RET_ADDR(ret, *sig); // TODO 调整返回地址?
}

void *executeMethodList(Object *ob, Class *class, MethodBlock *mb, u8 *jargs) {
    char *sig = mb->type;

    ExecEnv *ee = getExecEnv();
    uintptr_t *sp;
    void *ret;

    CREATE_TOP_FRAME(ee, class, mb, sp, ret);

    /* copy args onto stack */

    if(ob)
        *sp++ = (uintptr_t) ob; /* push receiver first */

    SCAN_SIG(sig, JA_DOUBLE(jargs, sp), JA_SINGLE(jargs, sp))

    if(mb->access_flags & ACC_SYNCHRONIZED)
        objectLock(ob ? ob : mb->class);

    if(mb->access_flags & ACC_NATIVE)
        (*mb->native_invoker)(class, mb, ret);
    else
        executeJava();

    if(mb->access_flags & ACC_SYNCHRONIZED)
        objectUnlock(ob ? ob : mb->class);

    POP_TOP_FRAME(ee);

    return ADJUST_RET_ADDR(ret, *sig);
}

