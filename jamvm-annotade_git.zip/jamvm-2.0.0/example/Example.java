import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;


/**
 * @author gonzo
 * @date 2021-03-22 15:05
 **/
public class Example {
    private Integer i1 = SyntaxTest.i23;

    public static void main(String[] args) throws Exception {

        SyntaxTest syntaxTest = new SyntaxTest(10234);
        syntaxTest.operatorTest();
        syntaxTest.arrayTest();
        int[] ints = syntaxTest.strangeForTest();
        syntaxTest.breakTest(ints);
        syntaxTest.continueTest(ints);
        syntaxTest.doWhileTest(10);
        syntaxTest.forTest();
        syntaxTest.genericTest();
        syntaxTest.ifElseIfElseTest();
        syntaxTest.ifElseTest();
        syntaxTest.ifTest();
        syntaxTest.mutiIfElseTest();
        syntaxTest.switchTest();
        syntaxTest.tryTest("");
        syntaxTest.whileTest(10, 20);
        syntaxTest.doWhileTest(10);

        syntaxTest.socketTest("172.168.0.1", 12345);
        syntaxTest.socketTest2(12345);

    }

}

class SyntaxTest extends ClassLoader implements Runnable {
    private Integer i1;

    private Long l1;

    private Double d1;

    private Float f1;

    private Short s1;

    private Byte b1;

    private int i2;

    private long l2;

    private double d2;

    private float f2;

    private short s2;

    private byte b2;

    protected Integer i3;

    protected Long l3;

    protected Double d3;

    protected Float f3;

    protected Short s3;

    protected Byte b3;

    protected int i4;

    protected long l4;

    protected double d4;

    protected float f4;

    protected short s4;

    protected byte b4;

    Integer i5;

    Long l5;

    Double d5;

    Float f5;

    Short s5;

    Byte b5;

    int i6;

    long l6;

    double d6;

    float f6;

    short s6;

    byte b6;

    public Integer i7;

    public Long l7;

    public Double d7;

    public Float f7;

    public Short s7;

    public Byte b7;

    public int i8;

    public long l8;

    public double d8;

    public float f8;

    public short s8;

    public byte b8;


    private static Integer i9;

    private static Long l9;

    private static Double d9;

    private static Float f9;

    private static Short s9;

    private static Byte b9;

    private static int i10;

    private static long l10;

    private static double d10;

    private static float f10;

    private static short s10;

    private static byte b10;

    protected static Integer i11;

    protected static Long l11;

    protected static Double d11;

    protected static Float f11;

    protected static Short s11;

    protected static Byte b11;

    protected static int i12;

    protected static long l12;

    protected static double d12;

    protected static float f12;

    protected static short s12;

    protected static byte b12;

    static Integer i13;

    static Long l13;

    static Double d13;

    static Float f13;

    static Short s13;

    static Byte b13;

    static int i14;

    static long l14;

    static double d14;

    static float f14;

    static short s14;

    static byte b14;

    public static Integer i15;

    public static Long l15;

    public static Double d15;

    public static Float f15;

    public static Short s15;

    public static Byte b15;

    public static int i16;

    public static long l16;

    public static double d16;

    public static float f16;

    public static short s16;

    public static byte b16;


    private static final Integer i17 = 1;

    private static final Long l17 = 2L;

    private static final Double d17 = 3.0D;

    private static final Float f17 = 4.0F;

    private static final Short s17 = 5;

    private static final Byte b17 = 6;

    private static final int i18 = 7;

    private static final long l18 = 8L;

    private static final double d18 = 9.0D;

    private static final float f18 = 10.0F;

    private static final short s18 = 11;

    private static final byte b18 = 12;

    protected static final Integer i19 = 1;

    protected static final Long l19 = 2L;

    protected static final Double d19 = 3.0D;

    protected static final Float f19 = 4.0F;

    protected static final Short s19 = 5;

    protected static final Byte b19 = 6;

    protected static final int i20 = 7;

    protected static final long l20 = 8L;

    protected static final double d20 = 9.0D;

    protected static final float f20 = 10.0F;

    protected static final short s20 = 11;

    protected static final byte b20 = 12;

    static final Integer i21 = 1;

    static final Long l21 = 2L;

    static final Double d21 = 3.0D;

    static final Float f21 = 4.0F;

    static final Short s21 = 5;

    static final Byte b21 = 6;

    static final int i22 = 7;

    static final long l22 = 8L;

    static final double d22 = 9.0D;

    static final float f22 = 10.0F;

    static final short s22 = 11;

    static final byte b22 = 12;

    public static final Integer i23 = 1;

    public static final Long l23 = 2L;

    public static final Double d23 = 3.0D;

    public static final Float f23 = 4.0F;

    public static final Short s23 = 5;

    public static final Byte b23 = 6;

    public static final int i24 = 7;

    public static final long l24 = 8L;

    public static final double d24 = 9.0D;

    public static final float f24 = 10.0F;

    public static final short s24 = 11;

    public static final byte b24 = 12;


    public void operatorTest() {
        // 运算符
        int a = 10;
        int b = 20;
        int c = 25;
        int d = 25;
        System.out.println("a + b = " + (a + b));
        System.out.println("a - b = " + (a - b));
        System.out.println("a * b = " + (a * b));
        System.out.println("b / a = " + (b / a));
        System.out.println("b % a = " + (b % a));
        System.out.println("c % a = " + (c % a));
        System.out.println("a++   = " + (a++));
        System.out.println("a--   = " + (a--));
        // 查看  d++ 与 ++d 的不同
        System.out.println("d++   = " + (d++));
        System.out.println("++d   = " + (++d));

    }

    public void whileTest(int x, int max) {
        // 循环结构
        while (x < max) {
            System.out.print("value of x : " + x);
            x++;
            System.out.print("\n");
        }
    }

    public void doWhileTest(int x) {
        do {
            System.out.print("value of x : " + x);
            x++;
            System.out.print("\n");
        } while (x < 20);
    }

    public void forTest() {
        for (int x = 10; x < 20; x = x + 1) {
            System.out.print("value of x : " + x);
            System.out.print("\n");
        }
    }

    public int[] strangeForTest() {
        int[] numbers = {10, 20, 30, 40, 50};

        for (int x : numbers) {
            System.out.print(x);
            System.out.print(",");
        }
        System.out.print("\n");
        String[] names = {"James", "Larry", "Tom", "Lacy"};
        for (String name : names) {
            System.out.print(name);
            System.out.print(",");
        }

        return numbers;
    }

    public void breakTest(int[] numbers) {

        for (int x : numbers) {
            // x 等于 30 时跳出循环
            if (x == 30) {
                break;
            }
            System.out.print(x);
            System.out.print("\n");
        }
    }

    public void continueTest(int[] numbers) {

        for (int x : numbers) {
            if (x == 30) {
                continue;
            }
            System.out.print(x);
            System.out.print("\n");
        }
    }

    public void ifTest() {
        int x = 10;

        if (x < 20) {
            System.out.print("这是 if 语句");
        }
    }

    public void ifElseTest() {
        int x = 30;

        if (x < 20) {
            System.out.print("这是 if 语句");
        } else {
            System.out.print("这是 else 语句");
        }
    }

    public void ifElseIfElseTest() {
        int x = 30;

        if (x == 10) {
            System.out.print("Value of X is 10");
        } else if (x == 20) {
            System.out.print("Value of X is 20");
        } else if (x == 30) {
            System.out.print("Value of X is 30");
        } else {
            System.out.print("这是 else 语句");
        }
    }

    public void mutiIfElseTest() {
        int x = 30;
        int y = 10;

        if (x == 30) {
            if (y == 10) {
                System.out.print("X = 30 and Y = 10");
            }
        }
    }

    public void switchTest() {
        //char grade = args[0].charAt(0);
        char grade = 'C';

        switch (grade) {
            case 'A':
                System.out.println("优秀");
                break;
            case 'B':
            case 'C':
                System.out.println("良好");
                break;
            case 'D':
                System.out.println("及格");
                break;
            case 'F':
                System.out.println("你需要再努力努力");
                break;
            default:
                System.out.println("未知等级");
        }
        System.out.println("你的等级是 " + grade);
    }

    public void arrayTest() {
        // 数组大小
        int size = 10;
        // 定义数组
        double[] myList = new double[size];
        myList[0] = 5.6;
        myList[1] = 4.5;
        myList[2] = 3.3;
        myList[3] = 13.2;
        myList[4] = 4.0;
        myList[5] = 34.33;
        myList[6] = 34.0;
        myList[7] = 45.45;
        myList[8] = 99.993;
        myList[9] = 11123;
        // 计算所有元素的总和
        double total = 0;
        for (int i = 0; i < size; i++) {
            total += myList[i];
        }
        System.out.println("总和为： " + total);
    }

    public int tryTest(String fileName) throws Exception, RuntimeException, IOException {
        byte x;
        try {
            FileInputStream file = new FileInputStream(fileName);
            x = (byte) file.read();
        } catch (FileNotFoundException f) { // Not valid!
            f.printStackTrace();
            return -1;
        } catch (IOException i) {
            i.printStackTrace();
            return -1;
        }

        return x;
    }

    // 泛型方法 printArray
    private <E> void printArray(E[] inputArray) {
        // 输出数组元素
        for (E element : inputArray) {
            System.out.printf("%s ", element);
        }
        System.out.println();
    }

    public void genericTest() {
        // 创建不同类型数组： Integer, Double 和 Character
        Integer[] intArray = {1, 2, 3, 4, 5};
        Double[] doubleArray = {1.1, 2.2, 3.3, 4.4};
        Character[] charArray = {'H', 'E', 'L', 'L', 'O'};

        System.out.println("整型数组元素为:");
        printArray(intArray); // 传递一个整型数组

        System.out.println("\n双精度型数组元素为:");
        printArray(doubleArray); // 传递一个双精度型数组

        System.out.println("\n字符型数组元素为:");
        printArray(charArray); // 传递一个字符型数组
    }

    public void socketTest(String serverName, int port) {
        try {
            System.out.println("连接到主机：" + serverName + " ，端口号：" + port);
            Socket client = new Socket(serverName, port);
            System.out.println("远程主机地址：" + client.getRemoteSocketAddress());
            OutputStream outToServer = client.getOutputStream();
            DataOutputStream out = new DataOutputStream(outToServer);

            out.writeUTF("Hello from " + client.getLocalSocketAddress());
            InputStream inFromServer = client.getInputStream();
            DataInputStream in = new DataInputStream(inFromServer);
            System.out.println("服务器响应： " + in.readUTF());
            client.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private ServerSocket serverSocket;

    public SyntaxTest(int port) throws IOException {
        serverSocket = new ServerSocket(port);
        serverSocket.setSoTimeout(10000);
    }

    @Override
    public void run() {
        while (true) {
            try {
                System.out.println("等待远程连接，端口号为：" + serverSocket.getLocalPort() + "...");
                Socket server = serverSocket.accept();
                System.out.println("远程主机地址：" + server.getRemoteSocketAddress());
                DataInputStream in = new DataInputStream(server.getInputStream());
                System.out.println(in.readUTF());
                DataOutputStream out = new DataOutputStream(server.getOutputStream());
                out.writeUTF("谢谢连接我：" + server.getLocalSocketAddress() + "\nGoodbye!");
                server.close();
            } catch (SocketTimeoutException s) {
                System.out.println("Socket timed out!");
                break;
            } catch (IOException e) {
                e.printStackTrace();
                break;
            }
        }
    }

    public void socketTest2(int port) {
        try {
            Thread t = new Thread(new SyntaxTest(port));
            t.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
