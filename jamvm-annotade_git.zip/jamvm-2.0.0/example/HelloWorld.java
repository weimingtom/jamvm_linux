import java.util.concurrent.locks.ReentrantLock;

public class HelloWorld { 
    /**private static final ReentrantLock lock = new ReentrantLock(); */

    private String s;

    private static int d = 0;

    static {
        System.out.println("HelloWorld static");
    }

    public static void main(String[] args) { 
       
        /**
        int i = 4;
        i++;
        ++i;
        Test hello = new Test();
        hello.setS(i);
        hello.test();
        hello = new Test();
         */
          d++;
        ++d;
         String a = "ab";
         int i = 4;
        i++;
        String b = "a" + "b";
        ++i;
       

        
        
        String c = new String(b);
        System.out.println(a == b);
        System.out.println(a == c);
        System.out.println(b == c);


        Test hello = new Test();
        hello.test2(new Test1() {
            public void test() {
                System.out.println("internal test");
            }
        });

        int s = 1;

        /**lock.lock();
        System.out.println("Hello Lock");
        lock.unlock(); */

        /*synchronized(HelloWorld.class) {
            System.out.println("Hello World"); 
        }
*/
        /**int i = 100;

        int j = 200;

        int c = 300; */

        // System.out.println(new HelloWorld().cal());
        // System.out.println("Hello World"); 
    } 

    /**public int cal() {
        int i = 100;

        int j = 200;

        int c = 300;

        return (i + j) * c;
    } */
}

class Parent {
    
    static {
        System.out.println("parent static");
    }

    public Parent() {
        System.out.println("parent init");
    }


}

class Test extends Parent{
    private volatile int s;

    static {
        System.out.println("Test static");
    }

    public Test() {
        System.out.println("Test init");
    }

    public void test() {
        System.out.println(s); 
    }

    public void setS(int s) {
        this.s = s;
    }

    public void test2(Test1 test1) {
        test1.test();
    }
}

interface Test1 {
    void test();
}